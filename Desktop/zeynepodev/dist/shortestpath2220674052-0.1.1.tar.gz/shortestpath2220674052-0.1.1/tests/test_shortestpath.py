import pytest
from shortestpath2220674052.shortestpath2220674052 import dijkstra, get_shortest_path, create_graph_from_edges


def test_create_graph_from_edges():
    edges = [
        ('A', 'B', 5),
        ('A', 'C', 3),
        ('B', 'C', 1),
        ('C', 'D', 2)
    ]
    
    expected_graph = {
        'A': {'B': 5, 'C': 3},
        'B': {'C': 1},
        'C': {'D': 2},
        'D': {}
    }
    
    assert create_graph_from_edges(edges) == expected_graph


def test_dijkstra():
    graph = {
        'A': {'B': 5, 'C': 3},
        'B': {'C': 1},
        'C': {'D': 2},
        'D': {}
    }
    
    distances, predecessors = dijkstra(graph, 'A')
    
    expected_distances = {
        'A': 0,
        'B': 5,
        'C': 3,
        'D': 5
    }
    
    expected_predecessors = {
        'A': None,
        'B': 'A',
        'C': 'A',
        'D': 'C'
    }
    
    assert distances == expected_distances
    assert predecessors == expected_predecessors


def test_get_shortest_path():
    graph = {
        'A': {'B': 5, 'C': 3},
        'B': {'C': 1},
        'C': {'D': 2},
        'D': {}
    }
    
    path, distance = get_shortest_path(graph, 'A', 'D')
    
    assert path == ['A', 'C', 'D']
    assert distance == 5
    
    # Test path not found
    graph = {
        'A': {'B': 1},
        'B': {'C': 1},
        'C': {},
        'D': {}
    }
    
    path, distance = get_shortest_path(graph, 'A', 'D')
    
    assert path is None
    assert distance is None 